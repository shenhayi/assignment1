### Usage:

**python main.py --render *args***

***args*=["1_1","1_2","2_1","2_2", "3", "4_1", "4_2", "4_3", "4_4", "5_1", "5_2_1", "5_2_2", "5_3_1", "5_3_2", "6"]** 

*where 1_1 means part 1 of question 1 and so on*

